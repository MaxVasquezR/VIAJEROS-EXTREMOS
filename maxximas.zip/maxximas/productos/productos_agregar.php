<?php
session_start();
if (!isset($_SESSION['usuario'])) { header("Location: /maxximas/login.php"); exit; }
require_once __DIR__ . '/../config/db.php';
include_once __DIR__ . '/../includes/header.php';
include_once __DIR__ . '/../includes/sidebar.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = trim($_POST['nombre']);
    $precio = floatval($_POST['precio']);
    $stock = intval($_POST['stock']);

    if ($nombre === '' || $precio <= 0) {
        echo "<script>alert('Nombre y precio válidos'); window.history.back();</script>";
        exit;
    }

    $sql = "INSERT INTO productos (nombre,precio,stock) VALUES (?,?,?)";
    $stmt = mysqli_prepare($conexion, $sql);
    mysqli_stmt_bind_param($stmt, "sdi", $nombre, $precio, $stock);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);

    header("Location: /maxximas/productos/productos.php");
    exit;
}
?>

<div class="pagina-modulo">
    <h1>Agregar Producto</h1>
    <form method="post">
        Nombre:<br><input type="text" name="nombre" required><br><br>
        Precio:<br><input type="number" step="0.01" name="precio" required><br><br>
        Stock:<br><input type="number" name="stock" value="0"><br><br>
        <button class="btn-volver" type="submit">Guardar</button>
        <a class="btn-volver" href="/maxximas/productos/productos.php">Volver</a>
    </form>
</div>

<?php include_once __DIR__ . '/../includes/footer.php'; ?>
