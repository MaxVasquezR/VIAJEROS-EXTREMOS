<?php
session_start();
if (!isset($_SESSION['usuario'])) { header("Location: /maxximas/login.php"); exit; }
require_once __DIR__ . '/../config/db.php';
include_once __DIR__ . '/../includes/header.php';
include_once __DIR__ . '/../includes/sidebar.php';

$res = mysqli_query($conexion, "SELECT * FROM productos ORDER BY id DESC");
?>

<div class="pagina-modulo">
    <h1>Productos</h1>
    <a class="btn-volver" href="/maxximas/productos/productos_agregar.php">Agregar Producto</a>
    <table class="tabla">
        <tr><th>ID</th><th>Nombre</th><th>Precio</th><th>Stock</th><th>Acciones</th></tr>
        <?php while($r = mysqli_fetch_assoc($res)): ?>
        <tr>
            <td><?= $r['id'] ?></td>
            <td><?= htmlspecialchars($r['nombre']) ?></td>
            <td><?= $r['precio'] ?></td>
            <td><?= $r['stock'] ?></td>
            <td>
                <a href="/maxximas/productos/productos_editar.php?id=<?= $r['id'] ?>">Editar</a> |
                <a href="/maxximas/productos/productos_eliminar.php?id=<?= $r['id'] ?>" onclick="return confirm('¿Eliminar?')">Eliminar</a>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>
</div>

<?php include_once __DIR__ . '/../includes/footer.php'; ?>
