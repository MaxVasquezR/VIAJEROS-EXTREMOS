<?php
session_start();
if (!isset($_SESSION['usuario'])) { header("Location: /maxximas/login.php"); exit; }
require_once __DIR__ . '/../config/db.php';
include_once __DIR__ . '/../includes/header.php';
include_once __DIR__ . '/../includes/sidebar.php';

$id = intval($_GET['id'] ?? 0);
$res = mysqli_query($conexion, "SELECT * FROM productos WHERE id=$id");
$prod = mysqli_fetch_assoc($res);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = mysqli_real_escape_string($conexion, $_POST['nombre']);
    $precio = floatval($_POST['precio']);
    $stock = intval($_POST['stock']);
    mysqli_query($conexion, "UPDATE productos SET nombre='$nombre', precio=$precio, stock=$stock WHERE id=$id");
    header("Location: /maxximas/productos/productos.php");
    exit;
}
?>

<div class="pagina-modulo">
    <h1>Editar Producto</h1>
    <form method="post">
        Nombre:<br><input type="text" name="nombre" value="<?= htmlspecialchars($prod['nombre']) ?>" required><br><br>
        Precio:<br><input type="number" step="0.01" name="precio" value="<?= $prod['precio'] ?>" required><br><br>
        Stock:<br><input type="number" name="stock" value="<?= $prod['stock'] ?>"><br><br>
        <button class="btn-volver" type="submit">Actualizar</button>
        <a class="btn-volver" href="/maxximas/productos/productos.php">Volver</a>
    </form>
</div>

<?php include_once __DIR__ . '/../includes/footer.php'; ?>
