<?php
session_start();
if (!isset($_SESSION['usuario'])) { header("Location: /maxximas/login.php"); exit; }
require_once __DIR__ . '/../config/db.php';
$id = intval($_GET['id'] ?? 0);
if ($id>0) mysqli_query($conexion, "DELETE FROM productos WHERE id=$id");
header("Location: /maxximas/productos/productos.php");
exit;
