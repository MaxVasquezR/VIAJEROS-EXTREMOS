<?php
session_start();
if (!isset($_SESSION['usuario'])) { header("Location: /maxximas/login.php"); exit; }
require_once __DIR__ . '/../config/db.php';
include_once __DIR__ . '/../includes/header.php';
include_once __DIR__ . '/../includes/sidebar.php';

$res = mysqli_query($conexion, "SELECT v.id, v.fecha, v.total, c.nombre as cliente, u.usuario as vendedor FROM ventas v LEFT JOIN clientes c ON v.id_cliente=c.id LEFT JOIN usuarios u ON v.id_usuario=u.id ORDER BY v.fecha DESC");
?>

<div class="pagina-modulo">
    <h1>Ventas</h1>
    <a class="btn-volver" href="/maxximas/ventas/ventas_agregar.php">Registrar Venta</a>
    <table class="tabla">
        <tr><th>ID</th><th>Fecha</th><th>Cliente</th><th>Vendedor</th><th>Total</th></tr>
        <?php while($r = mysqli_fetch_assoc($res)): ?>
        <tr>
            <td><?= $r['id'] ?></td>
            <td><?= $r['fecha'] ?></td>
            <td><?= htmlspecialchars($r['cliente']) ?></td>
            <td><?= htmlspecialchars($r['vendedor']) ?></td>
            <td><?= $r['total'] ?></td>
        </tr>
        <?php endwhile; ?>
    </table>
</div>

<?php include_once __DIR__ . '/../includes/footer.php'; ?>
