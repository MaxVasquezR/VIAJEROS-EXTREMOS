<?php
session_start();
if (!isset($_SESSION['usuario'])) { header("Location: /maxximas/login.php"); exit; }
require_once __DIR__ . '/../config/db.php';
include_once __DIR__ . '/../includes/header.php';
include_once __DIR__ . '/../includes/sidebar.php';

$clientes = mysqli_query($conexion, "SELECT * FROM clientes");
$productos = mysqli_query($conexion, "SELECT * FROM productos");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_cliente = intval($_POST['id_cliente']);
    $id_usuario = intval($_SESSION['id_usuario'] ?? 0);
    if ($id_cliente <= 0 || $id_usuario <= 0) {
        echo "<script>alert('Cliente o usuario inválido'); window.history.back();</script>";
        exit;
    }

    mysqli_begin_transaction($conexion);

    $sql = "INSERT INTO ventas (id_cliente,id_usuario,total) VALUES (?,?,0)";
    $stmt = mysqli_prepare($conexion, $sql);
    mysqli_stmt_bind_param($stmt, "ii", $id_cliente, $id_usuario);
    mysqli_stmt_execute($stmt);
    $id_venta = mysqli_insert_id($conexion);
    mysqli_stmt_close($stmt);

    $prod_ids = $_POST['producto'] ?? [];
    $cants = $_POST['cantidad'] ?? [];
    $precios = $_POST['precio'] ?? [];

    $total = 0;
    $stmt_det = mysqli_prepare($conexion, "INSERT INTO detalle_ventas (id_venta,id_producto,cantidad,precio_unitario,subtotal) VALUES (?,?,?,?,?)");
    for ($i=0;$i<count($prod_ids);$i++) {
        $pid = intval($prod_ids[$i]);
        $cant = intval($cants[$i]);
        $precio_unit = floatval($precios[$i]);
        if ($pid<=0 || $cant<=0 || $precio_unit<=0) continue;
        $sub = $cant * $precio_unit;
        $total += $sub;
        mysqli_stmt_bind_param($stmt_det, "iiidd", $id_venta, $pid, $cant, $precio_unit, $sub);
        mysqli_stmt_execute($stmt_det);
        mysqli_query($conexion, "UPDATE productos SET stock = stock - $cant WHERE id=$pid");
    }
    mysqli_stmt_close($stmt_det);

    mysqli_query($conexion, "UPDATE ventas SET total=$total WHERE id=$id_venta");
    mysqli_commit($conexion);

    header("Location: /maxximas/ventas/ventas.php");
    exit;
}
?>

<div class="pagina-modulo">
    <h1>Registrar Venta</h1>
    <form method="post">
        Cliente:<br>
        <select name="id_cliente">
            <?php while($c = mysqli_fetch_assoc($clientes)): ?>
            <option value="<?= $c['id'] ?>"><?= htmlspecialchars($c['nombre']) ?> (<?= $c['dni'] ?>)</option>
            <?php endwhile; ?>
        </select><br><br>

        <div id="lineas">
            <div class="linea">
                Producto:
                <select name="producto[]">
                    <?php mysqli_data_seek($productos,0); while($p = mysqli_fetch_assoc($productos)): ?>
                        <option value="<?= $p['id'] ?>"><?= htmlspecialchars($p['nombre']) ?> - S/<?= $p['precio'] ?></option>
                    <?php endwhile; ?>
                </select>
                Cantidad: <input type="number" name="cantidad[]" value="1" min="1">
                Precio: <input type="number" step="0.01" name="precio[]" value="0">
            </div>
        </div>

        <br>
        <button class="btn-volver" type="button" onclick="agregarLinea()">Agregar línea</button>
        <button class="btn-volver" type="submit">Guardar Venta</button>
        <a class="btn-volver" href="/maxximas/ventas/ventas.php">Volver</a>
    </form>
</div>

<script>
function agregarLinea(){
    var cont = document.getElementById('lineas');
    var div = document.createElement('div');
    div.className='linea';
    div.innerHTML = document.querySelector('.linea').innerHTML;
    cont.appendChild(div);
}
</script>

<?php include_once __DIR__ . '/../includes/footer.php'; ?>
