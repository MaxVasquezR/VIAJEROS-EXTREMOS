<?php
session_start();
require_once __DIR__ . '/config/db.php';

$usuario = $_POST['usuario'] ?? '';
$password = $_POST['password'] ?? '';
$rol      = $_POST['rol'] ?? '';

if (empty($usuario) || empty($password) || empty($rol)) {
    echo "<script>alert('Complete todos los campos'); window.location='/maxximas/login.php';</script>";
    exit;
}

/* Prepared statement */
$sql = "SELECT id, usuario, password, rol FROM usuarios WHERE usuario=? AND password=? AND rol=? LIMIT 1";
$stmt = mysqli_prepare($conexion, $sql);
mysqli_stmt_bind_param($stmt, "sss", $usuario, $password, $rol);
mysqli_stmt_execute($stmt);
$res = mysqli_stmt_get_result($stmt);

if ($res && mysqli_num_rows($res) > 0) {
    $data = mysqli_fetch_assoc($res);
    $_SESSION['usuario'] = $data['usuario'];
    $_SESSION['rol'] = $data['rol'];
    $_SESSION['id_usuario'] = $data['id'];
    header("Location: /maxximas/views/index.php");
    exit;
} else {
    echo "<script>alert('Usuario o contraseña incorrectos'); window.location='/maxximas/login.php';</script>";
    exit;
}
?>
