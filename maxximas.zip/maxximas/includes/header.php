<?php
if (session_status() === PHP_SESSION_NONE) session_start();
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>MAXXIMAS - Sistema</title>
<link rel="stylesheet" href="/maxximas/css/estilos.css">
</head>
<body>
<header class="header" style="background:#003366; padding:12px; color:#fff;">
    <div style="max-width:1100px; margin:0 auto; display:flex; justify-content:space-between; align-items:center;">
        <h2 style="margin:0;">MAXXIMAS</h2>
        <?php if(!empty($_SESSION['usuario'])): ?>
            <div style="text-align:right; font-size:14px;">
                <strong><?php echo htmlspecialchars($_SESSION['usuario']); ?></strong><br>
                <span style="font-size:12px;"><?php echo htmlspecialchars($_SESSION['rol'] ?? ''); ?></span>
            </div>
        <?php endif; ?>
    </div>
</header>
<div class="menu-layout">

