</main>
</div> <!-- cierre menu-layout -->
<footer style="background:#003366; color:white; padding:10px; text-align:center; margin-top:30px;">
    <small>MAXXIMAS © <?php echo date('Y'); ?></small>
</footer>
</body>
</html>
