<aside class="sidebar" style="width:230px; background:#204b82; color:white; padding:20px; border-radius:8px;">
    <div class="sidebar-logo" style="margin-bottom:18px;">
        <div class="logo-textos" style="font-weight:700;">PANEL DE CONTROL</div>
    </div>

    <nav class="sidebar-menu" style="margin-bottom:20px;">
        <a href="/maxximas/views/index.php">Inicio</a><br>
        <a href="/maxximas/productos/productos.php">Productos</a><br>
        <a href="/maxximas/clientes/clientes.php">Clientes</a><br>
        <a href="/maxximas/ventas/ventas.php">Ventas</a><br>
        <a href="/maxximas/usuarios/usuarios.php">Usuarios</a><br>
        <a href="/maxximas/views/reportes.php">Reportes</a><br>
    </nav>

    <a class="btn-logout" href="/maxximas/logout/salir.php" style="color:#ffdddd; text-decoration:none;">Cerrar sesión</a>
</aside>

<main class="contenido" style="flex:1; padding-left:20px;">
