1) Copia la carpeta 'maxximas' en C:\xampp\htdocs\
2) Inicia XAMPP: Apache + MySQL
3) En phpMyAdmin importa la BD (usa el SQL que viene abajo)
4) Asegúrate config/db.php usa root / '' por defecto
5) Accede a: http://localhost/maxximas/login.php
   Usuarios de prueba:
     admin / 1234 / Administrador
     cajero1 / 1234 / Cajero
     vendedor1 / 1234 / Vendedor
6) Si aparece Not Found, verifica que la carpeta se llame exactamente 'maxximas'
