
<?php
$conexion = mysqli_connect("localhost","root","","sistema");
if(!$conexion){
    die("Error al conectar: " . mysqli_connect_error());
}
?>
