<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>MAXXIMAS - Login</title>
<link rel="stylesheet" href="/maxximas/css/estilos.css">
</head>
<body>

<div class="layout">
    <div class="panel-izquierdo">
        <div class="logo-box">
            <div class="carrito">
                <div class="carrito-caja"></div>
                <div class="carrito-barra"></div>
                <div class="carrito-rueda r1"></div>
                <div class="carrito-rueda r2"></div>
            </div>
            <div class="logo-textos">
                <span class="titulo">MAXXIMAS MINIMARKET</span><div></div>
                <span class="subtitulo">SISTEMA WEB</span>
            </div>
        </div>
    </div>

    <div class="panel-derecho">
        <div class="card-login">
            <h1>Inicio de sesión</h1>

            <form action="/maxximas/validar.php" method="POST" class="form-login">
                <div class="campo">
                    <span class="icono">👤</span>
                    <input type="text" name="usuario" placeholder="Usuario" required>
                </div>

                <div class="campo">
                    <span class="icono">🔒</span>
                    <input type="password" name="password" placeholder="Contraseña" required>
                </div>

                <div class="campo">
                    <span class="icono">⚙️</span>
                    <select name="rol" required>
                        <option value="">Rol de acceso</option>
                        <option value="Administrador">Administrador</option>
                        <option value="Cajero">Cajero</option>
                        <option value="Vendedor">Vendedor</option>
                    </select>
                </div>

                <button type="submit" class="btn-login">Ingresar</button>
            </form>
        </div>
    </div>
</div>

</body>
</html>
