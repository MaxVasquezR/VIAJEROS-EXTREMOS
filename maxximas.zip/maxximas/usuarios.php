
<?php
session_start();
if(!isset($_SESSION['usuario'])){ header("Location: login.php"); exit; }
require_once "db.php";
$result = mysqli_query($conexion, "SELECT * FROM usuarios");
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Usuarios</title>
<link rel="stylesheet" href="estilos.css">
</head>
<body>
<div class="pagina-modulo">
    <h2>Gestión de Usuarios</h2>
    <table class="tabla">
        <tr><th>ID</th><th>Usuario</th><th>Rol</th></tr>
        <?php while($row = mysqli_fetch_assoc($result)): ?>
        <tr>
            <td><?php echo $row['id']; ?></td>
            <td><?php echo $row['usuario']; ?></td>
            <td><?php echo $row['rol']; ?></td>
        </tr>
        <?php endwhile; ?>
    </table>
    <a href="menu.php" class="btn-volver">Volver al menú</a>
</div>
</body>
</html>
