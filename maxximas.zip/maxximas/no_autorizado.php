<?php
session_start();

// Si no hay sesión, redirigir al login
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Acceso no autorizado</title>
    <link rel="stylesheet" href="/maxximas/css/estilos.css">
</head>
<body>

<div class="no-autorizado-container">
    <h1 class="no-autorizado-titulo">Acceso no autorizado</h1>
    <p class="no-autorizado-texto">
        No tienes permisos para acceder a esta sección del sistema.
    </p>

    <a href="/maxximas/views/index.php" class="btn-volver">Volver al menú</a>
</div>

</body>
</html>
