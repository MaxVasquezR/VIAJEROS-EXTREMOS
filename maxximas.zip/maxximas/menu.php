
<?php
session_start();
if(!isset($_SESSION['usuario'])){
    header("Location: login.php");
    exit;
}
$usuario = $_SESSION['usuario'];
$rol = $_SESSION['rol'];
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>MAXXIMAS - Menú</title>
<link rel="stylesheet" href="estilos.css">
</head>
<body>

<div class="menu-layout">
    <aside class="sidebar">
        <div class="sidebar-logo">
            <div class="carrito pequeño">
                <div class="carrito-caja"></div>
                <div class="carrito-barra"></div>
                <div class="carrito-rueda r1"></div>
                <div class="carrito-rueda r2"></div>
            </div>
            <span class="sidebar-title">MAXXIMAS</span>
        </div>
        <div class="sidebar-usuario">
            <strong><?php echo $usuario; ?></strong><br>
            <span><?php echo $rol; ?></span>
        </div>
        <nav class="sidebar-menu">
            <a href="menu.php">🏠 Inicio</a>
            <?php if($rol == 'Administrador'): ?>
                <a href="usuarios.php">👤 Usuarios</a>
                <a href="productos.php">📦 Productos</a>
                <a href="ventas.php">🛒 Ventas</a>
                <a href="caja.php">💳 Caja</a>
                <a href="clientes.php">👥 Clientes</a>
                <a href="reportes.php">📊 Reportes</a>
            <?php elseif($rol == 'Cajero'): ?>
                <a href="ventas.php">🛒 Ventas</a>
                <a href="caja.php">💳 Caja diaria</a>
            <?php elseif($rol == 'Vendedor'): ?>
                <a href="productos.php">📦 Productos</a>
                <a href="clientes.php">👥 Clientes</a>
                <a href="ventas.php">🛒 Ventas</a>
            <?php endif; ?>
        </nav>
        <a class="btn-logout" href="salir.php">Cerrar sesión</a>
    </aside>

    <main class="contenido">
        <h1>Bienvenido al sistema MAXXIMAS</h1>
        <p>Usuario: <strong><?php echo $usuario; ?></strong> | Rol: <strong><?php echo $rol; ?></strong></p>

        <div class="grid-tarjetas">
            <?php if($rol == 'Administrador'): ?>
                <a href="usuarios.php" class="tarjeta">
                    <h2>Usuarios</h2>
                    <p>Gestiona los usuarios y sus roles.</p>
                </a>
                <a href="productos.php" class="tarjeta">
                    <h2>Productos</h2>
                    <p>Registra y controla el stock.</p>
                </a>
                <a href="ventas.php" class="tarjeta">
                    <h2>Ventas</h2>
                    <p>Revisa y registra ventas.</p>
                </a>
                <a href="caja.php" class="tarjeta">
                    <h2>Caja</h2>
                    <p>Controla los movimientos de caja.</p>
                </a>
                <a href="clientes.php" class="tarjeta">
                    <h2>Clientes</h2>
                    <p>Administra la información de clientes.</p>
                </a>
                <a href="reportes.php" class="tarjeta">
                    <h2>Reportes</h2>
                    <p>Visualiza reportes generales del sistema.</p>
                </a>
            <?php elseif($rol == 'Cajero'): ?>
                <a href="ventas.php" class="tarjeta">
                    <h2>Ventas</h2>
                    <p>Registrar ventas del día.</p>
                </a>
                <a href="caja.php" class="tarjeta">
                    <h2>Caja diaria</h2>
                    <p>Ver y cerrar caja diaria.</p>
                </a>
            <?php elseif($rol == 'Vendedor'): ?>
                <a href="productos.php" class="tarjeta">
                    <h2>Productos</h2>
                    <p>Consultar catálogo de productos.</p>
                </a>
                <a href="clientes.php" class="tarjeta">
                    <h2>Clientes</h2>
                    <p>Ver y registrar clientes.</p>
                </a>
                <a href="ventas.php" class="tarjeta">
                    <h2>Ventas</h2>
                    <p>Apoyar en el proceso de ventas.</p>
                </a>
            <?php endif; ?>
        </div>
    </main>
</div>

</body>
</html>
