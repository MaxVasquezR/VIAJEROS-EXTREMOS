<?php
session_start();
if (!isset($_SESSION['usuario'])) { header("Location: /maxximas/login.php"); exit; }
require_once __DIR__ . '/../config/db.php';
include_once __DIR__ . '/../includes/header.php';
include_once __DIR__ . '/../includes/sidebar.php';

$id = intval($_GET['id'] ?? 0);
$res = mysqli_query($conexion, "SELECT * FROM usuarios WHERE id=$id");
$user = mysqli_fetch_assoc($res);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $usuario = mysqli_real_escape_string($conexion, $_POST['usuario']);
    $rol = mysqli_real_escape_string($conexion, $_POST['rol']);
    mysqli_query($conexion, "UPDATE usuarios SET usuario='$usuario', rol='$rol' WHERE id=$id");
    header("Location: /maxximas/usuarios/usuarios.php");
    exit;
}
?>

<div class="pagina-modulo">
    <h1>Editar Usuario</h1>
    <form method="post">
        Usuario:<br><input type="text" name="usuario" value="<?= htmlspecialchars($user['usuario']) ?>" required><br><br>
        Rol:<br>
        <select name="rol">
            <option <?= $user['rol']=='Administrador'?'selected':'' ?>>Administrador</option>
            <option <?= $user['rol']=='Cajero'?'selected':'' ?>>Cajero</option>
            <option <?= $user['rol']=='Vendedor'?'selected':'' ?>>Vendedor</option>
        </select><br><br>
        <button class="btn-volver" type="submit">Actualizar</button>
        <a class="btn-volver" href="/maxximas/usuarios/usuarios.php">Volver</a>
    </form>
</div>

<?php include_once __DIR__ . '/../includes/footer.php'; ?>
