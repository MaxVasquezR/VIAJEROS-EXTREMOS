<?php
session_start();
if (!isset($_SESSION['usuario'])) { header("Location: /maxximas/login.php"); exit; }
require_once __DIR__ . '/../config/db.php';
include_once __DIR__ . '/../includes/header.php';
include_once __DIR__ . '/../includes/sidebar.php';

$res = mysqli_query($conexion, "SELECT id,usuario,rol FROM usuarios ORDER BY id DESC");
?>

<div class="pagina-modulo">
    <h1>Usuarios</h1>
    <a class="btn-volver" href="/maxximas/usuarios/usuarios_agregar.php">Agregar Usuario</a>
    <table class="tabla">
        <tr><th>ID</th><th>Usuario</th><th>Rol</th><th>Acciones</th></tr>
        <?php while($r = mysqli_fetch_assoc($res)): ?>
        <tr>
            <td><?= $r['id'] ?></td>
            <td><?= htmlspecialchars($r['usuario']) ?></td>
            <td><?= htmlspecialchars($r['rol']) ?></td>
            <td>
                <a href="/maxximas/usuarios/usuarios_editar.php?id=<?= $r['id'] ?>">Editar</a> |
                <a href="/maxximas/usuarios/usuarios_eliminar.php?id=<?= $r['id'] ?>" onclick="return confirm('¿Eliminar?')">Eliminar</a>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>
</div>

<?php include_once __DIR__ . '/../includes/footer.php'; ?>
<?php
require_once "../includes/auth.php";
permitir(["Administrador"]);
?>