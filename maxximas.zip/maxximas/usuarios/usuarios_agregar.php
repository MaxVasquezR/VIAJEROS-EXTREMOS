<?php
session_start();
if (!isset($_SESSION['usuario'])) { header("Location: /maxximas/login.php"); exit; }
require_once __DIR__ . '/../config/db.php';
include_once __DIR__ . '/../includes/header.php';
include_once __DIR__ . '/../includes/sidebar.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $usuario = trim($_POST['usuario']);
    $password = trim($_POST['password']);
    $rol = trim($_POST['rol']);

    if ($usuario === '' || $password === '' || $rol === '') {
        echo "<script>alert('Complete todos los campos'); window.history.back();</script>";
        exit;
    }

    $sql = "INSERT INTO usuarios (usuario,password,rol) VALUES (?,?,?)";
    $stmt = mysqli_prepare($conexion, $sql);
    mysqli_stmt_bind_param($stmt, "sss", $usuario, $password, $rol);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);

    header("Location: /maxximas/usuarios/usuarios.php");
    exit;
}
?>

<div class="pagina-modulo">
    <h1>Agregar Usuario</h1>
    <form method="post">
        Usuario:<br><input type="text" name="usuario" required><br><br>
        Contraseña:<br><input type="password" name="password" required><br><br>
        Rol:<br><select name="rol"><option>Administrador</option><option>Cajero</option><option>Vendedor</option></select><br><br>
        <button class="btn-volver" type="submit">Guardar</button>
        <a class="btn-volver" href="/maxximas/usuarios/usuarios.php">Volver</a>
    </form>
</div>

<?php include_once __DIR__ . '/../includes/footer.php'; ?>
