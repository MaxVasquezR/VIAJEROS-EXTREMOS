
<?php
session_start();
if(!isset($_SESSION['usuario'])){ header("Location: login.php"); exit; }
require_once "db.php";
mysqli_query($conexion,"
CREATE TABLE IF NOT EXISTS productos(
id INT AUTO_INCREMENT PRIMARY KEY,
nombre VARCHAR(100),
precio DECIMAL(10,2)
)");
$result = mysqli_query($conexion, "SELECT * FROM productos");
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Productos</title>
<link rel="stylesheet" href="estilos.css">
</head>
<body>
<div class="pagina-modulo">
    <h2>Gestión de Productos</h2>
    <table class="tabla">
        <tr><th>ID</th><th>Nombre</th><th>Precio</th></tr>
        <?php while($row = mysqli_fetch_assoc($result)): ?>
        <tr>
            <td><?php echo $row['id']; ?></td>
            <td><?php echo $row['nombre']; ?></td>
            <td><?php echo $row['precio']; ?></td>
        </tr>
        <?php endwhile; ?>
    </table>
    <a href="menu.php" class="btn-volver">Volver al menú</a>
</div>
</body>
</html>
