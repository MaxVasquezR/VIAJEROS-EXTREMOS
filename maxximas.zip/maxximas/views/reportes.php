<?php
session_start();
if (!isset($_SESSION['usuario'])) { header("Location: /maxximas/login.php"); exit; }
include_once __DIR__ . '/../includes/header.php';
include_once __DIR__ . '/../includes/sidebar.php';
require_once __DIR__ . '/../config/db.php';
?>

<div class="contenido">
    <h1>Reportes</h1>
    <h3>Últimas 10 ventas</h3>
    <?php
    $res = mysqli_query($conexion, "SELECT v.id,v.fecha,v.total,c.nombre as cliente FROM ventas v LEFT JOIN clientes c ON v.id_cliente=c.id ORDER BY v.fecha DESC LIMIT 10");
    ?>
    <table class="tabla">
        <tr><th>ID</th><th>Fecha</th><th>Cliente</th><th>Total</th></tr>
        <?php while($r = mysqli_fetch_assoc($res)): ?>
        <tr>
            <td><?= $r['id'] ?></td>
            <td><?= $r['fecha'] ?></td>
            <td><?= htmlspecialchars($r['cliente']) ?></td>
            <td><?= $r['total'] ?></td>
        </tr>
        <?php endwhile; ?>
    </table>
</div>

<?php include_once __DIR__ . '/../includes/footer.php'; ?>
<?php
require_once "../includes/auth.php";
permitir(["Administrador"]);
?>