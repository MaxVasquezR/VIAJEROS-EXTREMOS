<?php
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/sidebar.php';
?>

<?php
require_once __DIR__ . '/../includes/footer.php';
?>