<?php
session_start();
if (!isset($_SESSION['usuario'])) { header("Location: /maxximas/login.php"); exit; }
include_once __DIR__ . '/../includes/header.php';
include_once __DIR__ . '/../includes/sidebar.php';
?>

<div class="contenido">
    <h1>Bienvenido, <?php echo htmlspecialchars($_SESSION['usuario']); ?></h1>
    <p>Rol: <?php echo htmlspecialchars($_SESSION['rol']); ?></p>

    <div class="grid-tarjetas">
        <a class="tarjeta" href="/maxximas/productos/productos.php"><h2>Productos</h2><p>Gestiona productos</p></a>
        <a class="tarjeta" href="/maxximas/clientes/clientes.php"><h2>Clientes</h2><p>Gestiona clientes</p></a>
        <a class="tarjeta" href="/maxximas/ventas/ventas.php"><h2>Ventas</h2><p>Registrar ventas</p></a>
        <a class="tarjeta" href="/maxximas/usuarios/usuarios.php"><h2>Usuarios</h2><p>Gestiona usuarios</p></a>
        <a class="tarjeta" href="/maxximas/views/reportes.php"><h2>Reportes</h2><p>Reportes y export</p></a>
    </div>
</div>

<?php include_once __DIR__ . '/../includes/footer.php'; ?>
