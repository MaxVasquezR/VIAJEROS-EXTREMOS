<?php
session_start();
if (!isset($_SESSION['usuario'])) { header("Location: /maxximas/login.php"); exit; }
require_once __DIR__ . '/../config/db.php';
include_once __DIR__ . '/../includes/header.php';
include_once __DIR__ . '/../includes/sidebar.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = trim($_POST['nombre']);
    $dni = trim($_POST['dni']);
    $telefono = trim($_POST['telefono']);
    $tipo = trim($_POST['tipo_comprobante']);

    if ($nombre === '' || $dni === '') {
        echo "<script>alert('Nombre y DNI requeridos'); window.history.back();</script>";
        exit;
    }

    $sql = "INSERT INTO clientes (nombre,dni,telefono,tipo_comprobante) VALUES (?,?,?,?)";
    $stmt = mysqli_prepare($conexion, $sql);
    mysqli_stmt_bind_param($stmt, "ssss", $nombre, $dni, $telefono, $tipo);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);

    header("Location: /maxximas/clientes/clientes.php");
    exit;
}
?>

<div class="pagina-modulo">
    <h1>Agregar Cliente</h1>
    <form method="post">
        Nombre:<br><input type="text" name="nombre" required><br><br>
        DNI:<br><input type="text" name="dni" required><br><br>
        Teléfono:<br><input type="text" name="telefono"><br><br>
        Tipo comprobante:<br>
        <select name="tipo_comprobante"><option>Boleta</option><option>Factura</option></select><br><br>
        <button class="btn-volver" type="submit">Guardar</button>
        <a class="btn-volver" href="/maxximas/clientes/clientes.php">Volver</a>
    </form>
</div>

<?php include_once __DIR__ . '/../includes/footer.php'; ?>
