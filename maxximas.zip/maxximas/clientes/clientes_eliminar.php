<?php
session_start();
if (!isset($_SESSION['usuario'])) { header("Location: /maxximas/login.php"); exit; }
require_once __DIR__ . '/../config/db.php';
$id = intval($_GET['id'] ?? 0);
if ($id>0) mysqli_query($conexion, "DELETE FROM clientes WHERE id=$id");
header("Location: /maxximas/clientes/clientes.php");
exit;
