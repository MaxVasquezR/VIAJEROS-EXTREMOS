<?php
session_start();
if (!isset($_SESSION['usuario'])) { header("Location: /maxximas/login.php"); exit; }
require_once __DIR__ . '/../config/db.php';
include_once __DIR__ . '/../includes/header.php';
include_once __DIR__ . '/../includes/sidebar.php';

$id = intval($_GET['id'] ?? 0);
$res = mysqli_query($conexion, "SELECT * FROM clientes WHERE id=$id");
$cli = mysqli_fetch_assoc($res);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = mysqli_real_escape_string($conexion, $_POST['nombre']);
    $dni = mysqli_real_escape_string($conexion, $_POST['dni']);
    $telefono = mysqli_real_escape_string($conexion, $_POST['telefono']);
    $tipo = mysqli_real_escape_string($conexion, $_POST['tipo_comprobante']);
    mysqli_query($conexion, "UPDATE clientes SET nombre='$nombre', dni='$dni', telefono='$telefono', tipo_comprobante='$tipo' WHERE id=$id");
    header("Location: /maxximas/clientes/clientes.php");
    exit;
}
?>

<div class="pagina-modulo">
    <h1>Editar Cliente</h1>
    <form method="post">
        Nombre:<br><input type="text" name="nombre" value="<?= htmlspecialchars($cli['nombre']) ?>" required><br><br>
        DNI:<br><input type="text" name="dni" value="<?= htmlspecialchars($cli['dni']) ?>" required><br><br>
        Teléfono:<br><input type="text" name="telefono" value="<?= htmlspecialchars($cli['telefono']) ?>"><br><br>
        Tipo comprobante:<br>
        <select name="tipo_comprobante">
            <option <?= $cli['tipo_comprobante']=='Boleta'?'selected':'' ?>>Boleta</option>
            <option <?= $cli['tipo_comprobante']=='Factura'?'selected':'' ?>>Factura</option>
        </select><br><br>
        <button class="btn-volver" type="submit">Actualizar</button>
        <a class="btn-volver" href="/maxximas/clientes/clientes.php">Volver</a>
    </form>
</div>

<?php include_once __DIR__ . '/../includes/footer.php'; ?>
