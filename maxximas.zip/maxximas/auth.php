<?php
// includes/auth.php
session_start();
if(!isset($_SESSION['usuario'])){
  header('Location: /MAXXIMAS/login.php');
  exit;
}
